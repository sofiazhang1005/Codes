import { motion } from "motion/react";
import { ProjectCard } from "../components/ProjectCard";

export function ResearchDesign() {
  return (
    <div className="w-full pt-24 pb-32">
      <div className="max-w-7xl mx-auto px-6">
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-3xl mb-16"
        >
          <h1 className="font-serif text-5xl text-stone-900 mb-6">Research × Design</h1>
          <p className="text-xl text-stone-600 leading-relaxed">
            My distinctive perspective is rooted in human development, psychology, and cognitive science. I use research not just to evaluate, but to generate design decisions that align with how humans actually learn and develop.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <ProjectCard 
            title="Cognition and Learning Research"
            category="Academic Research"
            description="Investigating the cognitive mechanisms underlying skill acquisition and knowledge transfer in digital environments."
            link="/research-design/cognition"
            imageUrl="https://picsum.photos/seed/research-1/800/600"
          />
          <ProjectCard 
            title="Research-Informed Design Thinking"
            category="Methodology"
            description="Developing a framework that integrates rigorous educational research methods with agile design thinking processes."
            link="/research-design/methodology"
            imageUrl="https://picsum.photos/seed/research-2/800/600"
          />
          <ProjectCard 
            title="Developmental Perspectives in EdTech"
            category="Applied Research"
            description="Applying theories of human development to the design of educational technologies for diverse age groups."
            link="/research-design/developmental"
            imageUrl="https://picsum.photos/seed/research-3/800/600"
          />
        </div>

      </div>
    </div>
  );
}
