import { motion } from "motion/react";
import { ArrowRight, Mail, Linkedin, FileText } from "lucide-react";

export function Contact() {
  return (
    <div className="w-full pt-24 pb-32 min-h-[80vh] flex items-center">
      <div className="max-w-3xl mx-auto px-6 w-full">
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="bg-white p-12 md:p-16 rounded-3xl shadow-sm border border-stone-100"
        >
          <h1 className="font-serif text-4xl md:text-5xl text-stone-900 mb-6">Let's Connect</h1>
          <p className="text-lg text-stone-600 leading-relaxed mb-12">
            I am always open to discussing learning design, educational innovation, and research collaborations. Whether you have a project in mind or just want to connect, I'd love to hear from you.
          </p>

          <div className="flex flex-col gap-6">
            <a 
              href="mailto:sofiayunqizhang@gmail.com" 
              className="flex items-center justify-between p-6 rounded-2xl bg-stone-50 hover:bg-stone-100 transition-colors group"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-sm text-stone-700">
                  <Mail size={20} />
                </div>
                <div>
                  <div className="text-sm text-stone-500 font-medium mb-1">Email</div>
                  <div className="text-stone-900 font-medium">sofiayunqizhang@gmail.com</div>
                </div>
              </div>
              <ArrowRight className="text-stone-400 group-hover:text-stone-900 transition-colors group-hover:translate-x-1" />
            </a>

            <a 
              href="#" 
              className="flex items-center justify-between p-6 rounded-2xl bg-stone-50 hover:bg-stone-100 transition-colors group"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-sm text-stone-700">
                  <Linkedin size={20} />
                </div>
                <div>
                  <div className="text-sm text-stone-500 font-medium mb-1">LinkedIn</div>
                  <div className="text-stone-900 font-medium">Connect professionally</div>
                </div>
              </div>
              <ArrowRight className="text-stone-400 group-hover:text-stone-900 transition-colors group-hover:translate-x-1" />
            </a>

            <a 
              href="#" 
              className="flex items-center justify-between p-6 rounded-2xl bg-stone-50 hover:bg-stone-100 transition-colors group"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-sm text-stone-700">
                  <FileText size={20} />
                </div>
                <div>
                  <div className="text-sm text-stone-500 font-medium mb-1">Resume / CV</div>
                  <div className="text-stone-900 font-medium">View my full experience</div>
                </div>
              </div>
              <ArrowRight className="text-stone-400 group-hover:text-stone-900 transition-colors group-hover:translate-x-1" />
            </a>
          </div>
        </motion.div>

      </div>
    </div>
  );
}
